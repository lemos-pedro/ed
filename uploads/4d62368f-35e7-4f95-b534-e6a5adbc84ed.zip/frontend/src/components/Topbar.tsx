import { useLocation } from "react-router-dom";
import { Plus, Bell, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SidebarTrigger } from "@/components/ui/sidebar";

const pageTitles: Record<string, { title: string; subtitle: string; action?: string }> = {
  "/": { title: "Dashboard", subtitle: "Visão geral dos seus projectos", action: "Novo Projecto" },
  "/projects": { title: "Projectos", subtitle: "Gerencie todos os seus projectos", action: "Novo Projecto" },
  "/tasks": { title: "Tarefas", subtitle: "Gestão de tarefas e actividades" },
  "/team": { title: "Team", subtitle: "Gestão de membros e desempenho", action: "Adicionar Membro" },
  "/chat": { title: "Chat", subtitle: "Comunicação da equipa" },
  "/meetings": { title: "Reuniões", subtitle: "Agenda e resumos de reuniões", action: "Nova Reunião" },
  "/reports": { title: "Relatórios", subtitle: "Análise e métricas de progresso" },
  "/ai": { title: "Assistente IA", subtitle: "Insights inteligentes dos seus projectos" },
};

export function Topbar() {
  const location = useLocation();
  const page = pageTitles[location.pathname] || pageTitles["/"];

  return (
    <header className="flex h-16 items-center justify-between border-b bg-card px-4 lg:px-6">
      <div className="flex items-center gap-3">
        <SidebarTrigger className="text-muted-foreground" />
        <div>
          <h1 className="text-lg font-semibold text-foreground">{page.title}</h1>
          <p className="text-xs text-muted-foreground">{page.subtitle}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" className="text-muted-foreground">
          <Search className="h-5 w-5" />
        </Button>
        <Button variant="ghost" size="icon" className="relative text-muted-foreground">
          <Bell className="h-5 w-5" />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-danger" />
        </Button>
        {page.action && (
          <Button size="sm" className="gap-1.5">
            <Plus className="h-4 w-4" />
            {page.action}
          </Button>
        )}
      </div>
    </header>
  );
}
