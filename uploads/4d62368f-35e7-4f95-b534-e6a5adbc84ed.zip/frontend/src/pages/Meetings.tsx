import { Video, Clock, CheckCircle, ListChecks, Bot } from "lucide-react";
import { Button } from "@/components/ui/button";

const todayMeetings = [
  { title: "Standup — Equipa Torres 5G", time: "09:00 — 09:30", attendees: 6, status: "Concluída" },
  { title: "Review Sprint — Fibra Benguela", time: "11:00 — 12:00", attendees: 8, status: "Em breve" },
  { title: "Sync com Cliente — Terminal Lobito", time: "15:00 — 16:00", attendees: 4, status: "Agendada" },
];

const aiSummary = {
  title: "Standup — Equipa Torres 5G",
  decisions: [
    "Priorizar instalação da Torre #12 esta semana",
    "Adiar manutenção da Torre #8 para próxima sprint",
    "Carlos Mendes vai contactar novo fornecedor de antenas",
  ],
  tasksCreated: [
    "Preparar relatório de instalação — Torre #12",
    "Contactar fornecedor AlphaTech — orçamento antenas",
    "Actualizar timeline no dashboard do projecto",
  ],
};

export default function Meetings() {
  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      {/* Today's meetings */}
      <div className="rounded-xl border bg-card p-5 shadow-sm">
        <h2 className="mb-4 text-base font-semibold text-foreground">Reuniões de Hoje</h2>
        <div className="space-y-3">
          {todayMeetings.map((m) => (
            <div key={m.title} className="flex items-center gap-4 rounded-lg bg-muted/50 p-4">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <Video className="h-5 w-5" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium text-foreground">{m.title}</p>
                <p className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="h-3 w-3" /> {m.time} · {m.attendees} participantes
                </p>
              </div>
              {m.status === "Em breve" ? (
                <Button size="sm">Entrar</Button>
              ) : (
                <span className="text-xs text-muted-foreground">{m.status}</span>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* AI Summary */}
      <div className="rounded-xl border bg-card p-5 shadow-sm">
        <div className="mb-4 flex items-center gap-2">
          <Bot className="h-5 w-5 text-primary" />
          <h2 className="text-base font-semibold text-foreground">Resumo IA — {aiSummary.title}</h2>
        </div>

        <div className="mb-4">
          <h3 className="mb-2 flex items-center gap-2 text-sm font-medium text-foreground">
            <CheckCircle className="h-4 w-4 text-success" /> Decisões Tomadas
          </h3>
          <ul className="space-y-1.5 pl-6">
            {aiSummary.decisions.map((d) => (
              <li key={d} className="text-sm text-muted-foreground list-disc">{d}</li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="mb-2 flex items-center gap-2 text-sm font-medium text-foreground">
            <ListChecks className="h-4 w-4 text-primary" /> Tarefas Criadas Automaticamente
          </h3>
          <ul className="space-y-1.5 pl-6">
            {aiSummary.tasksCreated.map((t) => (
              <li key={t} className="text-sm text-muted-foreground list-disc">{t}</li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
