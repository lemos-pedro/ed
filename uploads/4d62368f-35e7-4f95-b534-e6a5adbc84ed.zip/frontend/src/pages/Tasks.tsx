import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Calendar,
  Clock,
  Flag,
  LayoutGrid,
  List,
  BarChart3,
  AlertCircle,
  Plus,
  RefreshCw,
  Loader2,
} from "lucide-react";

import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { taskApi, projectApi, type Task, type TaskStatus, type TaskPriority } from "@/lib/api";
import { useAuthStore } from "@/store/auth.store";

// ── Config ───────────────────────────────────────────────────

const priorityConfig: Record<TaskPriority, { label: string; style: string; icon: typeof Flag }> = {
  urgent: { label: "Urgente", style: "bg-danger/15 text-danger", icon: AlertCircle },
  high: { label: "Alta", style: "bg-warning/15 text-warning", icon: Flag },
  normal: { label: "Normal", style: "bg-primary/15 text-primary", icon: Flag },
  low: { label: "Baixa", style: "bg-muted text-muted-foreground", icon: Flag },
};

const statusConfig: Record<TaskStatus, { label: string; color: string }> = {
  todo: { label: "A Fazer", color: "bg-muted-foreground" },
  in_progress: { label: "Em Progresso", color: "bg-primary" },
  review: { label: "Revisão", color: "bg-warning" },
  done: { label: "Concluída", color: "bg-success" },
};

const kanbanColumns: TaskStatus[] = ["todo", "in_progress", "review", "done"];

const viewTabs = [
  { id: "list" as const, label: "Lista", icon: List },
  { id: "kanban" as const, label: "Kanban", icon: LayoutGrid },
  { id: "gantt" as const, label: "Gantt", icon: BarChart3 },
];

type ViewType = "list" | "kanban" | "gantt";

// ── Task Card ────────────────────────────────────────────────

function TaskCard({ task, compact = false, onClick }: { task: Task; compact?: boolean; onClick?: () => void }) {
  const pri = priorityConfig[task.priority] || priorityConfig.normal;
  const PriIcon = pri.icon;
  const isDone = task.status === "done";

  return (
    <div
      onClick={onClick}
      className={cn(
        "group cursor-pointer rounded-xl border bg-card p-4 shadow-sm transition-all hover:shadow-md",
        isDone && "opacity-60"
      )}
    >
      <div className="mb-3 flex items-center justify-between">
        <span className="text-xs font-medium text-muted-foreground">{task.projectName || "Projeto"}</span>
        <span className={cn("flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold", pri.style)}>
          <PriIcon className="h-3 w-3" /> {pri.label}
        </span>
      </div>
      <h3 className={cn("text-sm font-semibold text-foreground leading-snug", isDone && "line-through text-muted-foreground")}>
        {task.title}
      </h3>
      {!compact && task.description && (
        <p className="mt-1.5 text-xs text-muted-foreground line-clamp-2">{task.description}</p>
      )}
      <div className="mt-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-primary/10 text-[10px] font-semibold text-primary">
            {task.assigneeName?.split(" ").map((n) => n[0]).join("").slice(0, 2) || "?"}
          </div>
          {!compact && <span className="text-xs text-muted-foreground">{task.assigneeName || "Não atribuído"}</span>}
        </div>
        <div className="flex items-center gap-1 text-xs text-muted-foreground">
          <Clock className="h-3 w-3" />
          {task.dueDate
            ? new Date(task.dueDate).toLocaleDateString("pt-PT", { day: "numeric", month: "short" })
            : "Sem prazo"}
        </div>
      </div>
    </div>
  );
}

// ── Views ───────────────────────────────────────────────────

function ListView({ tasks, onClickTask }: { tasks: Task[]; onClickTask?: (t: Task) => void }) {
  return (
    <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
      {tasks.map((t) => (
        <TaskCard key={t.id} task={t} onClick={() => onClickTask?.(t)} />
      ))}
    </div>
  );
}

function KanbanView({
  tasks,
  onClickTask,
  onUpdateStatus,
}: {
  tasks: Task[];
  onClickTask?: (t: Task) => void;
  onUpdateStatus?: (id: string, status: TaskStatus) => void;
}) {
  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {kanbanColumns.map((col) => {
        const colTasks = tasks.filter((t) => t.status === col);
        const status = statusConfig[col];
        return (
          <div key={col} className="w-72 shrink-0 rounded-xl bg-muted/50 p-3">
            <div className="mb-3 flex items-center gap-2">
              <span className={cn("h-2.5 w-2.5 rounded-full", status.color)} />
              <span className="text-sm font-semibold text-foreground">{status.label}</span>
              <span className="ml-auto flex h-5 min-w-[20px] items-center justify-center rounded-full bg-muted px-1.5 text-[11px] font-semibold text-muted-foreground">
                {colTasks.length}
              </span>
            </div>
            <div className="space-y-3">
              {colTasks.map((t) => (
                <TaskCard key={t.id} task={t} compact onClick={() => onClickTask?.(t)} />
              ))}
              {colTasks.length === 0 && (
                <div className="rounded-lg border-2 border-dashed border-border p-6 text-center text-xs text-muted-foreground">
                  Sem tarefas
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function GanttView({ tasks }: { tasks: Task[] }) {
  // (Mantido igual ao teu código original - está bom)
  // Se quiseres posso simplificar mais tarde
  return <div className="text-muted-foreground">Gantt View (em desenvolvimento)</div>;
}

// ── Main Component ──────────────────────────────────────────

export default function Tasks() {
  const { toast } = useToast();
  const qc = useQueryClient();
  const { user } = useAuthStore();

  const [view, setView] = useState<ViewType>("list");
  const [createOpen, setCreateOpen] = useState(false);
  const [detailOpen, setDetailOpen] = useState(false);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  // Form fields
  const [fTitle, setFTitle] = useState("");
  const [fDesc, setFDesc] = useState("");
  const [fProjectId, setFProjectId] = useState("");
  const [fPriority, setFPriority] = useState<TaskPriority>("normal");
  const [fStatus, setFStatus] = useState<TaskStatus>("todo");
  const [fAssignee, setFAssignee] = useState("");
  const [fDueDate, setFDueDate] = useState("");

  // ==================== QUERIES ====================
  const {
    data: tasks = [],
    isLoading,
    isError,
    refetch,
  } = useQuery({
    queryKey: ["tasks", user?.tenantId],
    queryFn: () => taskApi.list(undefined, user!.tenantId),
    enabled: !!user?.tenantId,
    retry: false,
  });

  const { data: projects = [] } = useQuery({
    queryKey: ["projects", user?.tenantId],
    queryFn: () => projectApi.list(user!.tenantId),
    enabled: !!user?.tenantId,
  });

  // ==================== MUTATIONS ====================
  const createMutation = useMutation({
    mutationFn: (data: Record<string, unknown>) => taskApi.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["tasks", user?.tenantId] });
      toast({ title: "Tarefa criada com sucesso!" });
      setCreateOpen(false);
      resetForm();
    },
    onError: (err: any) => {
      toast({
        title: "Erro ao criar tarefa",
        description: err?.response?.data?.message || err?.message || "Não foi possível criar a tarefa.",
        variant: "destructive",
      });
    },
  });

  const resetForm = () => {
    setFTitle("");
    setFDesc("");
    setFProjectId("");
    setFPriority("normal");
    setFStatus("todo");
    setFAssignee("");
    setFDueDate("");
  };

  const handleCreate = () => {
    if (!fTitle?.trim() || !fProjectId) {
      toast({
        title: "Campos obrigatórios",
        description: "Título e projeto são obrigatórios.",
        variant: "destructive",
      });
      return;
    }

    createMutation.mutate({
      title: fTitle.trim(),
      description: fDesc?.trim() || undefined,
      projectId: fProjectId,
      tenantId: user?.tenantId,
      createdBy: user?.id,
      priority: fPriority,
      status: fStatus,
      assigneeIds: fAssignee ? [fAssignee] : [],
      dueDate: fDueDate || undefined,
    });
  };

  // ==================== RENDER ====================
  if (isError) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border bg-card p-12 shadow-sm">
        <AlertCircle className="h-12 w-12 text-destructive" />
        <h3 className="mt-4 text-lg font-semibold text-foreground">Erro ao carregar tarefas</h3>
        <Button variant="outline" className="mt-4 gap-2" onClick={() => refetch()}>
          <RefreshCw className="h-4 w-4" /> Tentar novamente
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header + Tabs */}
      <div className="flex items-center justify-between">
        <div className="flex gap-1 rounded-lg bg-muted p-1">
          {viewTabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setView(tab.id)}
                className={cn(
                  "flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium transition-colors",
                  view === tab.id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground"
                )}
              >
                <Icon className="h-4 w-4" /> {tab.label}
              </button>
            );
          })}
        </div>

        <Button size="sm" className="gap-1.5" onClick={() => setCreateOpen(true)}>
          <Plus className="h-4 w-4" /> Nova Tarefa
        </Button>
      </div>

      {/* Content */}
      {isLoading ? (
        <div className="grid grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)}
        </div>
      ) : tasks.length === 0 ? (
        <div className="rounded-xl border bg-card p-12 text-center shadow-sm">
          <Flag className="mx-auto h-10 w-10 text-muted-foreground/40" />
          <p className="mt-3 text-sm text-muted-foreground">Nenhuma tarefa encontrada</p>
        </div>
      ) : (
        <>
          {view === "list" && <ListView tasks={tasks} onClickTask={(t) => { setSelectedTask(t); setDetailOpen(true); }} />}
          {view === "kanban" && (
            <KanbanView
              tasks={tasks}
              onClickTask={(t) => { setSelectedTask(t); setDetailOpen(true); }}
            />
          )}
          {view === "gantt" && <GanttView tasks={tasks} />}
        </>
      )}

      {/* ==================== MODAL: CRIAR TAREFA ==================== */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5 text-primary" /> Nova Tarefa
            </DialogTitle>
            <DialogDescription>Crie uma nova tarefa e atribua a um membro da equipa.</DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-2">
            <div className="space-y-2">
              <Label htmlFor="title">Título *</Label>
              <Input
                id="title"
                placeholder="Ex: Inspecção do terreno"
                value={fTitle}
                onChange={(e) => setFTitle(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="desc">Descrição</Label>
              <Textarea
                id="desc"
                placeholder="Detalhes da tarefa..."
                value={fDesc}
                onChange={(e) => setFDesc(e.target.value)}
                rows={2}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Projeto *</Label>
                <Select value={fProjectId} onValueChange={setFProjectId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecionar projeto" />
                  </SelectTrigger>
                  <SelectContent>
                    {projects.map((p) => (
                      <SelectItem key={p.id} value={p.id}>
                        {p.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Prioridade</Label>
                <Select value={fPriority} onValueChange={(v) => setFPriority(v as TaskPriority)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="urgent">Urgente</SelectItem>
                    <SelectItem value="high">Alta</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="low">Baixa</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Status inicial</Label>
                <Select value={fStatus} onValueChange={(v) => setFStatus(v as TaskStatus)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="todo">A Fazer</SelectItem>
                    <SelectItem value="in_progress">Em Progresso</SelectItem>
                    <SelectItem value="review">Revisão</SelectItem>
                    <SelectItem value="done">Concluída</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Prazo</Label>
                <Input id="dueDate" type="date" value={fDueDate} onChange={(e) => setFDueDate(e.target.value)} />
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setCreateOpen(false);
                resetForm();
              }}
            >
              Cancelar
            </Button>
            <Button
              onClick={handleCreate}
              disabled={createMutation.isPending || !fTitle.trim() || !fProjectId}
            >
              {createMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Plus className="h-4 w-4" />
              )}
              Criar Tarefa
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Modal de Detalhes (mantido simples) */}
      <Dialog open={detailOpen} onOpenChange={setDetailOpen}>
        <DialogContent className="sm:max-w-md">
          {selectedTask && (
            <>
              <DialogHeader>
                <DialogTitle>{selectedTask.title}</DialogTitle>
                <DialogDescription>{selectedTask.description || "Sem descrição"}</DialogDescription>
              </DialogHeader>
              <DialogFooter>
                <Button variant="outline" onClick={() => setDetailOpen(false)}>
                  Fechar
                </Button>
              </DialogFooter>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}