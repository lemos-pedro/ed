// store/auth.store.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { setTokens, clearTokens } from '@/lib/api';

export interface User {
  id: string;
  email: string;
  fullName: string;
  role: 'admin' | 'manager' | 'member';
  tenantId: string;
  onboardingComplete: boolean;
}

interface AuthState {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  isLoading: boolean;

  login: (email: string, password: string) => Promise<void>;
  register: (data: { email: string; password: string; fullName: string }) => Promise<void>;
  logout: () => void;
  setUser: (user: User) => void;
  completeOnboarding: () => void;
  refreshSession: () => Promise<void>;
  fetchWithAuth: (input: RequestInfo, init?: RequestInit) => Promise<any>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      accessToken: null,
      refreshToken: null,
      isLoading: false,

      login: async (email, password) => {
        set({ isLoading: true });
        try {
          if (!email || !password) throw new Error('Email e password são obrigatórios');

          const res = await fetch('http://localhost:3000/api/v1/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, password }),
          });

          if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData.message || 'Email ou password incorrectos.');
          }

          const data = await res.json();
          setTokens(data.tokens.accessToken, data.tokens.refreshToken);

          const meRes = await fetch('http://localhost:3000/api/v1/me', {
            headers: { Authorization: `Bearer ${data.tokens.accessToken}` },
          });

          if (!meRes.ok) throw new Error('Falha ao obter dados do usuário.');
          const me = await meRes.json();

          set({
            user: { ...me, role: 'admin', onboardingComplete: true } as User,
            accessToken: data.tokens.accessToken,
            refreshToken: data.tokens.refreshToken,
            isLoading: false,
          });
        } catch (err: any) {
          set({ isLoading: false });
          throw err;
        }
      },

      register: async (data) => {
        set({ isLoading: true });
        try {
          const res = await fetch('http://localhost:3000/api/v1/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
          });

          if (!res.ok) {
            const errData = await res.json().catch(() => ({}));
            throw new Error(errData.message || 'Não foi possível criar a conta.');
          }

          const tokens = await res.json();
          setTokens(tokens.tokens.accessToken, tokens.tokens.refreshToken);

          const meRes = await fetch('http://localhost:3000/api/v1/me', {
            headers: { Authorization: `Bearer ${tokens.tokens.accessToken}` },
          });

          if (!meRes.ok) throw new Error('Falha ao obter dados do usuário.');
          const me = await meRes.json();

          set({
            user: { ...me, role: 'admin', onboardingComplete: false } as User,
            accessToken: tokens.tokens.accessToken,
            refreshToken: tokens.tokens.refreshToken,
            isLoading: false,
          });
        } catch (err: any) {
          set({ isLoading: false });
          throw err;
        }
      },

      logout: () => {
        const { refreshToken } = get();
        if (refreshToken) {
          fetch('http://localhost:3000/api/v1/auth/logout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ refreshToken }),
          }).catch(() => {});
        }
        clearTokens();
        set({ user: null, accessToken: null, refreshToken: null });
      },

      setUser: (user) => set({ user }),

      completeOnboarding: () => {
        const { user } = get();
        if (user) set({ user: { ...user, onboardingComplete: true } });
      },

      refreshSession: async () => {
        const { refreshToken } = get();
        if (!refreshToken) return;
        try {
          const res = await fetch('http://localhost:3000/api/v1/auth/refresh', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ refreshToken }),
          });

          if (!res.ok) throw new Error('Falha ao atualizar sessão.');

          const data = await res.json();
          setTokens(data.accessToken, data.refreshToken);
          set({ accessToken: data.accessToken, refreshToken: data.refreshToken });
        } catch {
          get().logout();
        }
      },

      fetchWithAuth: async (input: RequestInfo, init?: RequestInit) => {
        const { accessToken, refreshSession, logout } = get();
        if (!accessToken) throw new Error('Usuário não autenticado.');

        let headers = init?.headers
          ? { ...init.headers, Authorization: `Bearer ${accessToken}` }
          : { Authorization: `Bearer ${accessToken}` };

        const res = await fetch(input, { ...init, headers });

        if (res.status === 401) {
          await refreshSession();
          const newToken = get().accessToken;
          if (!newToken) throw new Error('Falha ao renovar token.');
          headers = { ...headers, Authorization: `Bearer ${newToken}` };
          return fetch(input, { ...init, headers });
        }

        return res;
      },
    }),

    // ==================== PERSIST CONFIG (com onRehydrateStorage) ====================
    {
      name: 'ngola-auth',
      partialize: (s) => ({
        accessToken: s.accessToken,
        refreshToken: s.refreshToken,
        user: s.user,
      }),

      onRehydrateStorage: () => (state) => {
        if (state?.accessToken && state?.refreshToken) {
          setTokens(state.accessToken, state.refreshToken);
        }
      },
    }
  )
);