import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::",
    port: 8080,
    hmr: {
      overlay: false,
    },
    // ✅ CSP Corrigido - Resolve Google Fonts + unsafe-eval
    headers: {
      "Content-Security-Policy": `
        default-src 'self';
        script-src 'self' 'unsafe-inline' 'unsafe-eval';
        style-src 'self' 'unsafe-inline' https://fonts.googleapis.com;
        font-src 'self' https://fonts.gstatic.com;
        connect-src 'self' http://localhost:* ws://localhost:* wss://localhost:*;
        img-src 'self' data: blob:;
        object-src 'none';
        base-uri 'self';
        upgrade-insecure-requests;
      `.trim().replace(/\s+/g, " "),
    },
  },

  plugins: [react(), mode === "development" && componentTagger()].filter(Boolean),

  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
    dedupe: ["react", "react-dom", "react/jsx-runtime", "react/jsx-dev-runtime"],
  },

  // Configuração para build de produção
  build: {
    rollupOptions: {
      output: {
        manualChunks: undefined,
      },
    },
  },
}));